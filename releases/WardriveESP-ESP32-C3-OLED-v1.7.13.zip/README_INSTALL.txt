WardriveESP v1.7.13 firmware package

SUPPORTED BOARD
  ESP32-C3 0.42-inch OLED development board
  Firmware board ID: esp32c3_oled042
  Screen: onboard 72x40 SSD1306-compatible OLED, SDA GPIO5, SCL GPIO6
  Blue LED: GPIO8 (active-low). BOOT button: GPIO9.

CHANGES
  Fixes Axon matching when AXEOFF service IDs are advertised inside 128-bit BLE service UUIDs.
  Keeps the 16-bit BLE UUID, company ID and Wi-Fi signature checks from v1.7.12.
  An AXON match flashes the blue LED and shows AX on the OLED.
  Short-press BOOT cycles through the dashboard, latest AXON log and radio statistics.

INSTALL
1. Install Python 3 and esptool (or install ESP-IDF 5.5+).
2. Connect the board by USB and find its serial port in Device Manager.
3. Open a terminal in this folder and run, replacing COM4 if Windows assigned a different port:

  python -m esptool --chip esp32c3 -p COM4 -b 460800 write_flash --flash_mode dio --flash_freq 80m --flash_size 4MB 0x0 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0xe000 ota_data_initial.bin 0x20000 WardriveESP-esp32c3-app.bin

The board restarts when flashing completes. This is the v1.7.13 image built for the board listed above. COM4 is only an example: select the port actually assigned to your board. Flashing replaces the current firmware.
