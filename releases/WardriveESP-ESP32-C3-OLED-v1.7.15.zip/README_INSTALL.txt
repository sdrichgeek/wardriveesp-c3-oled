WardriveESP v1.7.15 — standalone Axon detector

SUPPORTED BOARD
  ESP32-C3 0.42-inch OLED development board
  Firmware board ID: esp32c3_oled042; 4 MB flash
  OLED: onboard 72x40 SSD1306-compatible panel, SDA GPIO5, SCL GPIO6
  Blue LED: GPIO8 (active-low). BOOT button: GPIO9.

STANDALONE AXON DETECTION
  No Wardrive Go connection is needed. After boot, the board automatically scans BLE for 45 seconds, then performs 15 seconds of passive Wi-Fi capture, and repeats. BLE service IDs, company ID and MAC signatures plus the supported Wi-Fi probe-request signature are checked. An Axon match flashes the LED and displays AX. The compact OLED shows AXON ACTIVE when no phone is connected.
  Short-press BOOT to cycle the dashboard, latest Axon hit, and radio statistics. The latest hit and count are held in RAM and reset at reboot; this board has no local SD logging.
  Wardrive Go remains optional. Connecting it hands the scanner to the app's normal mode controls; after disconnect, standalone scanning resumes.

INSTALL
1. Install Python 3 and esptool (or ESP-IDF 5.5+).
2. Connect the board by USB and identify its serial port in Device Manager.
3. Open a terminal in this folder and run the command below, replacing COM4 with the assigned port:

  python -m esptool --chip esp32c3 -p COM4 -b 460800 write_flash --flash_mode dio --flash_freq 80m --flash_size 4MB 0x0 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0xe000 ota_data_initial.bin 0x20000 WardriveESP-esp32c3-app.bin

Wait for the board to restart. The image is built for the board listed above. Flashing replaces the current firmware. SHA256SUMS.txt contains checksums for the package files.
