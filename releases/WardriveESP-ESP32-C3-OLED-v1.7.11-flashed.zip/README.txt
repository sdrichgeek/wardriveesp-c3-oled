WardriveESP firmware flashed to the three ESP32-C3 0.42-inch OLED boards
Firmware: 1.7.11 (the last successfully built and flashed image; does not include the in-progress AXEOFF feature)
Target: ESP32-C3, 4 MB flash

Flash map (from the build used for flashing):
  0x0000  bootloader/bootloader.bin
  0x8000  partition_table/partition-table.bin
  0xE000  ota_data_initial.bin
  0x20000 wardrive_bridge.bin

Flash a board from this folder with ESP-IDF/esptool installed:
  idf.py -p COMx -b 460800 flash

Alternatively run esptool from this folder:
  py -m esptool --chip esp32c3 -p COMx -b 460800 write_flash --flash_mode dio --flash_freq 80m --flash_size 4MB 0x0 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0xe000 ota_data_initial.bin 0x20000 wardrive_bridge.bin

Use the COM port assigned to the board you connect. The three boards were flashed individually; same image for each.
